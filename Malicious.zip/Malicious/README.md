# Malicious 
![](https://img.shields.io/badge/Python-2.7/2.6-yellowgreen.svg)
![](https://img.shields.io/badge/version-1.1-brightgreen.svg)
## Requirements pip2 and gem
![](https://img.shields.io/badge/pip2-requests%20&%20tqdm-brightgreen.svg)
![](https://img.shields.io/badge/gem-lolcat-blue.svg)


![alt text](https://github.com/Hider5/Malicious/blob/master/image/ss.jpg)

### Installation Termux
```
$termux-setup-storage
$cd /sdcard
$pkg install git
$pkg install python2
$pkg install ruby
$gem install lolcat
$git clone https://github.com/Hider5/Malicious
$cd Malicious
$pip2 install -r requirements.txt
$python2 malicious.py
```
*after download virus open your file explorer*

*find folder Malicious and open it*

*chose and open folder Android if you download virus Android*
### Installation Linux
```
$apt-get install git
$apt-get install python2 ruby
$gem install lolcat
$git clone https://github.com/Hider5/Malicious
$cd Malicious
$pip2 install -r requirements.txt
$python2 malicious.py
```
